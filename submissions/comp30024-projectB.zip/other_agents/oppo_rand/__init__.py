# An agent plays the game using random strategy

from oppo_rand.player import Player
