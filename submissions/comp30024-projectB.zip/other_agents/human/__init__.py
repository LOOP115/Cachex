# A human player using command line inputs to play

from human.player import Player
